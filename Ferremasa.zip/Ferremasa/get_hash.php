<?php
// get_hash.php — SOLO para generar hashes
echo password_hash('c123456', PASSWORD_DEFAULT);
?>

