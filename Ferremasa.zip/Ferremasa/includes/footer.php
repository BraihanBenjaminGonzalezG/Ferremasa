<?php
// includes/footer.php
?>
  </main>
  <footer>
    <p>&copy; <?php echo date('Y'); ?> FERREMASA. Todos los derechos reservados.</p>
  </footer>
</body>
</html>
